package org.hdcd.config;

import javax.sql.DataSource;

import org.hdcd.common.security.CustomAccessDeniedHandler;
import org.hdcd.common.security.CustomLoginSuccessHandler;
import org.hdcd.common.security.CustomNoOpPasswordEncoder;
import org.hdcd.common.security.CustomUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import lombok.extern.java.Log;

@Log
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter{
	@Autowired
	DataSource dataSource;
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		log.info("security config ...");
		
		http.authorizeRequests()
		.antMatchers("/board/list")
		.permitAll();
		
		http.authorizeRequests()
		.antMatchers("/board/register")
		.hasAuthority("MEMBER");
		
		http.authorizeRequests()
		.antMatchers("/notice/list")
		.permitAll();
		
		http.authorizeRequests()
		.antMatchers("/notice/register")
		.hasAuthority("ADMIN");
		
		http.formLogin()
		.loginPage("/login")
		.successHandler(createAuthenticationSuccessHandler());
		
		http.exceptionHandling()
		.accessDeniedHandler(createAccessDeniedHandler());
		
		http.logout()
		.logoutUrl("/logout")
		.invalidateHttpSession(true);
		
	}
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
//		auth.inMemoryAuthentication()
//		.withUser("member")
//		.password("{noop}1234")
//		.roles("MEMBER");
//		
//		auth.inMemoryAuthentication()
//		.withUser("admin")
//		.password("{noop}1234")
//		.roles("ADMIN");
		//사용자 정의테이블로 인증 처리하기 위한 SQL 쿼리
		String queryForMember = "SELECT email, password, enabled FROM member where email = ?";
		String queryForRole = "select a.email, a.authority from auth a, member b where a.email = b.email and b.email = ?";
		
		// UserDetailsService 재정의
		// 스프링 시큐리티의 UserDetailsService를 구현하여 사용자 상세 정보를 얻어오는 메서드를 재정의한다.
		//CustomUserDetailService 빈을 인증 제공자에게 지정한다.
		auth.userDetailsService(createUserDetailsService())
		.passwordEncoder(createPasswordEncoder());
		
		auth.jdbcAuthentication()
		//데이터 소스를 지정
		.dataSource(dataSource)
		//작성한 쿼리를 지정
		.usersByUsernameQuery(queryForMember)
		.authoritiesByUsernameQuery(queryForRole)
		//실제 가입시엔 스프링 시큐리티에서 제공되는 BCryptPasswordEncoder 클래스를 빈으로 등록해서 여기 주입해야한다.
		//기본적으로 스프링5부터는 페스워드가 Encrypt 되어 들어가기 때문
		.passwordEncoder(createPasswordEncoder());
	}	
	
	@Bean
	public AccessDeniedHandler createAccessDeniedHandler() {
		return new CustomAccessDeniedHandler();
	}
	
	@Bean
	public AuthenticationSuccessHandler createAuthenticationSuccessHandler() {
		return new CustomLoginSuccessHandler();
	}
	
	@Bean
	public PasswordEncoder createPasswordEncoder() {
		//실제 암호화를 위해 들어가야할 값 return new BCryptPasswordEncoder();
		return new CustomNoOpPasswordEncoder();
	}
	
	//스프링 시큐리티의 UserDetailsService를 구현한 클래스를 빈으로 등록한다.
	@Bean
	public UserDetailsService createUserDetailsService() {
		return new CustomUserDetailsService();
	}
	
	
}
