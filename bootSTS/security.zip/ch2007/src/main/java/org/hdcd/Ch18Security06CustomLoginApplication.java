package org.hdcd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch18Security06CustomLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ch18Security06CustomLoginApplication.class, args);
	}

}
