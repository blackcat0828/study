package day0105;

public class Student {

}
