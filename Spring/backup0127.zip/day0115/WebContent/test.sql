insert into member 
 values ('m1000','m1234','이순신',50,'남자','test@naver.com');
 
commit
