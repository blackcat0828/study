package org.fintech.service;

public interface SampleService {
	public Integer doAdd(String str1, String str2) throws Exception;
}
