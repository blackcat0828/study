package sample;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ExamController {
	@GetMapping("/exam/test1")
	public ModelAndView test1() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("/exam/test");
		
		String test1 = "exam test1 page";
		mv.addObject("test1", test1);

		return mv;
	}
	
	@GetMapping("/exam/test2")
	public ModelAndView test2() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("/exam/test");
		
		String test2 = "exam test2 page";
		mv.addObject("test2", test2);

		return mv;
	}
	
	@GetMapping("/exam/test3")
	public ModelAndView test3() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("/exam/test");
		
		String test3 = "exam test3 page";
		mv.addObject("test3", test3);

		return mv;
	}
}
