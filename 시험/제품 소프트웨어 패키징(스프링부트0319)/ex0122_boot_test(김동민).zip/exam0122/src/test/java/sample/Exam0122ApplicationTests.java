package sample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exam0122ApplicationTests {

	@Test
	void contextLoads() {
	}

}
