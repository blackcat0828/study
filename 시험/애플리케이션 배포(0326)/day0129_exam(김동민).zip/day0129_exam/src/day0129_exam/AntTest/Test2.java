package day0129_exam.AntTest;

public class Test2 {
	public static void main(String[] args) {
		System.out.println("이 프로그램은 Test2.java 입니다.");
	}
}
