package sample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exam0216ApplicationTests {

	@Test
	void contextLoads() {
	}

}
