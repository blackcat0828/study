package sample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exam0216Application {

	public static void main(String[] args) {
		SpringApplication.run(Exam0216Application.class, args);
	}

}
