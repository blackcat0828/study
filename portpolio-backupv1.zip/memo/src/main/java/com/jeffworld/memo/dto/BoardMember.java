package com.jeffworld.memo.dto;

import lombok.Data;

@Data
public class BoardMember {
	private int pboardid;
	private String boardMember;
}
