package com.jeffworld.memo.dto;

import lombok.Data;

@Data
public class MemberAuth {

	private String email;
	private String authority;

}
