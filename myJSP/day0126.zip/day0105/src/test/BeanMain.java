package test;

public class BeanMain {
	public static void main(String[] args) {
		
		BeanTest b = new BeanTest();
		System.out.println(b.getName());

	}

}
