package test;

public class BeanTest {
	
	//멤버변수
	private String name = "홍길동";

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	

}
